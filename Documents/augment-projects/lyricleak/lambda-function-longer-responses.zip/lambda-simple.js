// Simple Lambda function for LyricLeak API
const https = require('https');
const querystring = require('querystring');

function makeRequest(url, options = {}) {
  return new Promise((resolve, reject) => {
    const req = https.request(url, options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          if (res.headers['content-type']?.includes('application/json')) {
            resolve(JSON.parse(data));
          } else {
            resolve(data);
          }
        } catch (e) {
          resolve(data);
        }
      });
    });
    req.on('error', reject);
    if (options.body) {
      req.write(options.body);
    }
    req.end();
  });
}

async function suggestArtistForSong(song) {
  // Simple hardcoded suggestions for common songs to avoid API complexity
  const commonSongs = {
    'yesterday': 'Beatles',
    'hello': 'Adele',
    'imagine': 'John Lennon',
    'bohemian rhapsody': 'Queen',
    'stairway to heaven': 'Led Zeppelin',
    'hotel california': 'Eagles',
    'sweet child o mine': 'Guns N Roses',
    'smells like teen spirit': 'Nirvana',
    'billie jean': 'Michael Jackson',
    'like a rolling stone': 'Bob Dylan',
    'detroit rock city': 'Kiss',
    'jeremy': 'Pearl Jam'
  };

  const lowerSong = song.toLowerCase().trim();
  if (commonSongs[lowerSong]) {
    return {
      artist: commonSongs[lowerSong],
      correctedSong: song,
      confidence: 'high'
    };
  }

  // For other songs, try OpenAI but with better error handling
  if (!process.env.OPENAI_API_KEY) return null;

  try {
    const body = JSON.stringify({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: "You are a music expert. When given a song title, identify the most famous artist. Respond with ONLY a JSON object like: {\"artist\": \"Artist Name\", \"correctedSong\": \"Song Title\", \"confidence\": \"high\"}"
        },
        {
          role: "user",
          content: `Most famous artist for "${song}"?`
        }
      ],
      max_tokens: 50,
      temperature: 0.1
    });

    const response = await makeRequest('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`
      },
      body: body
    });

    const content = response?.choices?.[0]?.message?.content?.trim();
    if (!content) return null;

    // Clean the content to ensure it's valid JSON
    const cleanContent = content.replace(/```json|```/g, '').trim();

    try {
      const result = JSON.parse(cleanContent);
      if (result && result.artist) {
        return {
          artist: result.artist,
          correctedSong: result.correctedSong || song,
          confidence: result.confidence || 'medium'
        };
      }
    } catch (e) {
      console.error('JSON parse error:', e, 'Content:', cleanContent);
    }

    return null;
  } catch (e) {
    console.error('Artist suggestion error:', e);
    return null;
  }
}

async function getFromOpenAI(song, artist) {
  if (!process.env.OPENAI_API_KEY) return null;

  const prompt = `What is the detailed story, meaning, and inspiration behind "${song}" by ${artist}? Include specific context, real events, and human stories. ALWAYS include 1-2 key lyric quotes that best illustrate the song's meaning. Write in 2-3 engaging paragraphs. Focus on compelling stories, tragedies, or real incidents if they exist.`;

  const body = JSON.stringify({
    model: "gpt-4o-mini",
    messages: [
      {
        role: "system",
        content: "You write comprehensive, engaging song-meaning summaries in 3-5 detailed paragraphs. Focus on the compelling story, inspiration, or meaning behind the song. Include specific details, real events, and human stories. ALWAYS include 2-3 key lyric quotes that illustrate the meaning, formatted with quotation marks. If there was a death, accident, tragedy, or specific event, describe it with appropriate detail and context. Include background about the songwriter's state of mind, the recording process, cultural impact, and any interesting trivia. Make it informative, engaging, and comprehensive - provide the full story behind the song. DO NOT start with the song title - jump straight into the story."
      },
      { role: "user", content: prompt }
    ],
    max_tokens: 1200,
    temperature: 0.2
  });

  try {
    const response = await makeRequest('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`
      },
      body: body
    });

    return response?.choices?.[0]?.message?.content?.trim() || null;
  } catch (e) {
    console.error('OpenAI error:', e);
    return null;
  }
}

exports.handler = async (event) => {
  console.log('Event:', JSON.stringify(event, null, 2));
  
  // Handle CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
      },
      body: ''
    };
  }

  // Parse query parameters
  const params = event.queryStringParameters || {};
  const song = params.song || '';
  const artist = params.artist || '';

  if (!song) {
    return {
      statusCode: 400,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ error: 'song parameter is required' })
    };
  }

  // If no artist provided, try to suggest one
  if (!artist || !artist.trim()) {
    try {
      const suggestion = await suggestArtistForSong(song.trim());
      if (suggestion) {
        const correctedSong = suggestion.correctedSong || song.trim();
        const originalSong = song.trim();
        const songChanged = correctedSong.toLowerCase() !== originalSong.toLowerCase();

        let message;
        if (songChanged) {
          message = `Did you mean "${correctedSong}" by ${suggestion.artist}?`;
        } else {
          message = `Did you mean "${correctedSong}" by ${suggestion.artist}?`;
        }

        return {
          statusCode: 200,
          headers: {
            'Access-Control-Allow-Origin': '*',
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            suggestion: true,
            originalSong: originalSong,
            correctedSong: correctedSong,
            suggestedArtist: suggestion.artist,
            confidence: suggestion.confidence,
            songChanged: songChanged,
            message: message,
            searchUrl: `/api/meaning?song=${encodeURIComponent(correctedSong)}&artist=${encodeURIComponent(suggestion.artist)}`
          })
        };
      } else {
        return {
          statusCode: 400,
          headers: {
            'Access-Control-Allow-Origin': '*',
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            error: "Artist name is required. Could not automatically identify the artist for this song.",
            suggestion: false
          })
        };
      }
    } catch (e) {
      return {
        statusCode: 400,
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ error: 'artist parameter is required' })
      };
    }
  }

  try {
    const meaning = await getFromOpenAI(song.trim(), artist.trim());
    
    if (!meaning) {
      return {
        statusCode: 404,
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ error: 'Could not find meaning for this song' })
      };
    }

    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        song: song.trim(),
        artist: artist.trim(),
        meaning: meaning
      })
    };
  } catch (error) {
    console.error('Handler error:', error);
    return {
      statusCode: 500,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ error: 'Internal server error' })
    };
  }
};
