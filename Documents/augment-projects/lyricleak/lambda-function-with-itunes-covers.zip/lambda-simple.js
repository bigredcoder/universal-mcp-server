// Simple Lambda function for LyricLeak API
const https = require('https');
const querystring = require('querystring');

// YouTube Search Functions
async function searchYouTube(query, maxResults = 10) {
  const apiKey = process.env.YOUTUBE_API_KEY;
  if (!apiKey) {
    console.log('No YouTube API key - using fallback search');
    return null;
  }

  const searchUrl = `https://www.googleapis.com/youtube/v3/search?part=snippet&q=${encodeURIComponent(query)}&type=video&maxResults=${maxResults}&key=${apiKey}`;

  try {
    const response = await fetch(searchUrl);
    const data = await response.json();
    return data.items || [];
  } catch (error) {
    console.log('YouTube API error:', error.message);
    return null;
  }
}

// Fast YouTube Search - No AI analysis, just search
async function youtubeSearchAgent(query) {
  console.log('🤖 Fast YouTube Search starting for:', query);

  const results = {
    query: query,
    success: false,
    videoId: null,
    confidence: 1,
    reasoning: '',
    toolsUsed: ['youtube_search'],
    logs: []
  };

  try {
    // Simple, fast search
    results.logs.push('🔍 Searching YouTube...');
    const searchQuery = `${query} official`;
    const videos = await searchYouTube(searchQuery, 3);

    if (videos && videos.length > 0) {
      // Just take the first result - YouTube's algorithm is usually good
      const video = videos[0];
      results.success = true;
      results.videoId = video.id.videoId;
      results.reasoning = `Found: "${video.snippet.title}"`;
      results.logs.push(`📺 Found: "${video.snippet.title}"`);
      results.logs.push('✅ Using first result');
    } else {
      results.logs.push('❌ No videos found');
      results.reasoning = 'No videos found';
    }

  } catch (error) {
    results.logs.push(`❌ Error: ${error.message}`);
    results.reasoning = `Error: ${error.message}`;
  }

  console.log('🤖 Fast search completed:', results);
  return results;
}

// Album cover AI agent function
async function getAlbumCover(song, artist) {
  if (!process.env.OPENAI_API_KEY) return null;

  try {
    console.log(`🎨 Getting album cover for: "${song}" by ${artist}`);

    // Use AI to identify the correct album information only
    const prompt = `You are a music expert. For the song "${song}" by ${artist}, identify the original album it was released on.

Respond with ONLY a JSON object containing:
{
  "album": "exact album name",
  "year": "release year",
  "confidence": "high/medium/low"
}

Be accurate about the album name and year. Do not include any URLs.`;

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [{ role: 'user', content: prompt }],
        max_tokens: 150,
        temperature: 0.1
      })
    });

    if (!response.ok) {
      throw new Error(`OpenAI API error: ${response.status}`);
    }

    const data = await response.json();
    const content = data.choices[0].message.content.trim();

    try {
      const albumInfo = JSON.parse(content);
      console.log(`🎨 Album identified: ${albumInfo.album} (${albumInfo.year})`);

      // Try to find album cover using iTunes Search API
      let coverUrl = null;
      try {
        const searchQuery = `${artist} ${albumInfo.album}`.replace(/[^a-zA-Z0-9\s]/g, '');
        const itunesUrl = `https://itunes.apple.com/search?term=${encodeURIComponent(searchQuery)}&media=music&entity=album&limit=1`;

        console.log(`🔍 Searching iTunes for: ${searchQuery}`);
        const itunesResponse = await fetch(itunesUrl);
        const itunesData = await itunesResponse.json();

        if (itunesData.results && itunesData.results.length > 0) {
          const album = itunesData.results[0];
          // Get high-resolution artwork (600x600)
          coverUrl = album.artworkUrl100?.replace('100x100', '600x600') || album.artworkUrl100;
          console.log(`🎨 Found iTunes cover: ${coverUrl}`);
        }
      } catch (itunesError) {
        console.log('iTunes search failed:', itunesError.message);
      }

      // Fallback to a styled placeholder if no cover found
      if (!coverUrl) {
        coverUrl = `https://via.placeholder.com/300x300/2d1b69/ffffff?text=${encodeURIComponent(albumInfo.album)}`;
      }

      return {
        album: albumInfo.album,
        year: albumInfo.year,
        coverUrl: coverUrl,
        confidence: albumInfo.confidence
      };
    } catch (parseError) {
      console.log('Failed to parse album info JSON:', content);
      return null;
    }
  } catch (error) {
    console.error('Album cover error:', error);
    return null;
  }
}

function makeRequest(url, options = {}) {
  return new Promise((resolve, reject) => {
    const req = https.request(url, options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          if (res.headers['content-type']?.includes('application/json')) {
            resolve(JSON.parse(data));
          } else {
            resolve(data);
          }
        } catch (e) {
          resolve(data);
        }
      });
    });
    req.on('error', reject);
    if (options.body) {
      req.write(options.body);
    }
    req.end();
  });
}

async function suggestArtistForSong(song) {
  // Simple hardcoded suggestions for common songs to avoid API complexity
  const commonSongs = {
    'yesterday': 'Beatles',
    'hello': 'Adele',
    'imagine': 'John Lennon',
    'bohemian rhapsody': 'Queen',
    'stairway to heaven': 'Led Zeppelin',
    'hotel california': 'Eagles',
    'sweet child o mine': 'Guns N Roses',
    'smells like teen spirit': 'Nirvana',
    'billie jean': 'Michael Jackson',
    'like a rolling stone': 'Bob Dylan',
    'detroit rock city': 'Kiss',
    'jeremy': 'Pearl Jam'
  };

  const lowerSong = song.toLowerCase().trim();
  if (commonSongs[lowerSong]) {
    return {
      artist: commonSongs[lowerSong],
      correctedSong: song,
      confidence: 'high'
    };
  }

  // For other songs, try OpenAI but with better error handling
  if (!process.env.OPENAI_API_KEY) return null;

  try {
    const body = JSON.stringify({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: "You are a music expert. When given a song title, identify the most famous artist. Respond with ONLY a JSON object like: {\"artist\": \"Artist Name\", \"correctedSong\": \"Song Title\", \"confidence\": \"high\"}"
        },
        {
          role: "user",
          content: `Most famous artist for "${song}"?`
        }
      ],
      max_tokens: 50,
      temperature: 0.1
    });

    const response = await makeRequest('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`
      },
      body: body
    });

    const content = response?.choices?.[0]?.message?.content?.trim();
    if (!content) return null;

    // Clean the content to ensure it's valid JSON
    const cleanContent = content.replace(/```json|```/g, '').trim();

    try {
      const result = JSON.parse(cleanContent);
      if (result && result.artist) {
        return {
          artist: result.artist,
          correctedSong: result.correctedSong || song,
          confidence: result.confidence || 'medium'
        };
      }
    } catch (e) {
      console.error('JSON parse error:', e, 'Content:', cleanContent);
    }

    return null;
  } catch (e) {
    console.error('Artist suggestion error:', e);
    return null;
  }
}

async function getFromOpenAI(song, artist) {
  if (!process.env.OPENAI_API_KEY) return null;

  const prompt = `What is the detailed story, meaning, and inspiration behind "${song}" by ${artist}? Include specific context, real events, and human stories. ALWAYS include 1-2 key lyric quotes that best illustrate the song's meaning. Write in 2-3 engaging paragraphs. Focus on compelling stories, tragedies, or real incidents if they exist.`;

  const body = JSON.stringify({
    model: "gpt-4o-mini",
    messages: [
      {
        role: "system",
        content: "You write comprehensive, engaging song-meaning summaries in 3-5 detailed paragraphs. Focus on the compelling story, inspiration, or meaning behind the song. Include specific details, real events, and human stories. ALWAYS include 2-3 key lyric quotes that illustrate the meaning, formatted with quotation marks. If there was a death, accident, tragedy, or specific event, describe it with appropriate detail and context. Include background about the songwriter's state of mind, the recording process, cultural impact, and any interesting trivia. Make it informative, engaging, and comprehensive - provide the full story behind the song. DO NOT start with the song title - jump straight into the story."
      },
      { role: "user", content: prompt }
    ],
    max_tokens: 1200,
    temperature: 0.2
  });

  try {
    const response = await makeRequest('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`
      },
      body: body
    });

    return response?.choices?.[0]?.message?.content?.trim() || null;
  } catch (e) {
    console.error('OpenAI error:', e);
    return null;
  }
}

exports.handler = async (event) => {
  console.log('Event:', JSON.stringify(event, null, 2));
  
  // Handle CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
      },
      body: ''
    };
  }

  // Check if this is a YouTube search request
  const path = event.path || event.pathParameters?.proxy || '';
  if (path.includes('youtube-search')) {
    const params = event.queryStringParameters || {};
    const query = params.query || '';

    if (!query) {
      return {
        statusCode: 400,
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ error: 'query parameter is required' })
      };
    }

    try {
      const result = await youtubeSearchAgent(query);
      return {
        statusCode: 200,
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(result)
      };
    } catch (error) {
      console.error('YouTube search error:', error);
      return {
        statusCode: 500,
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ error: 'YouTube search failed' })
      };
    }
  }

  // Parse query parameters for song meaning requests
  const params = event.queryStringParameters || {};
  const song = params.song || '';
  const artist = params.artist || '';

  if (!song) {
    return {
      statusCode: 400,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ error: 'song parameter is required' })
    };
  }

  // If no artist provided, try to suggest one
  if (!artist || !artist.trim()) {
    try {
      const suggestion = await suggestArtistForSong(song.trim());
      if (suggestion) {
        const correctedSong = suggestion.correctedSong || song.trim();
        const originalSong = song.trim();
        const songChanged = correctedSong.toLowerCase() !== originalSong.toLowerCase();

        let message;
        if (songChanged) {
          message = `Did you mean "${correctedSong}" by ${suggestion.artist}?`;
        } else {
          message = `Did you mean "${correctedSong}" by ${suggestion.artist}?`;
        }

        return {
          statusCode: 200,
          headers: {
            'Access-Control-Allow-Origin': '*',
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            suggestion: true,
            originalSong: originalSong,
            correctedSong: correctedSong,
            suggestedArtist: suggestion.artist,
            confidence: suggestion.confidence,
            songChanged: songChanged,
            message: message,
            searchUrl: `/api/meaning?song=${encodeURIComponent(correctedSong)}&artist=${encodeURIComponent(suggestion.artist)}`
          })
        };
      } else {
        return {
          statusCode: 400,
          headers: {
            'Access-Control-Allow-Origin': '*',
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            error: "Artist name is required. Could not automatically identify the artist for this song.",
            suggestion: false
          })
        };
      }
    } catch (e) {
      return {
        statusCode: 400,
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ error: 'artist parameter is required' })
      };
    }
  }

  try {
    // Fetch both meaning and album cover in parallel for better performance
    const [meaning, albumCover] = await Promise.all([
      getFromOpenAI(song.trim(), artist.trim()),
      getAlbumCover(song.trim(), artist.trim())
    ]);

    if (!meaning) {
      return {
        statusCode: 404,
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ error: 'Could not find meaning for this song' })
      };
    }

    const response = {
      song: song.trim(),
      artist: artist.trim(),
      meaning: meaning
    };

    // Add album cover information if available
    if (albumCover) {
      response.album = {
        name: albumCover.album,
        year: albumCover.year,
        coverUrl: albumCover.coverUrl,
        confidence: albumCover.confidence
      };
    }

    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(response)
    };
  } catch (error) {
    console.error('Handler error:', error);
    return {
      statusCode: 500,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ error: 'Internal server error' })
    };
  }
};
