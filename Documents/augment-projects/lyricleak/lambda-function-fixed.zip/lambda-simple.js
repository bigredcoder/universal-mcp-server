// Simple Lambda function for LyricLeak API
const https = require('https');
const querystring = require('querystring');

function makeRequest(url, options = {}) {
  return new Promise((resolve, reject) => {
    const req = https.request(url, options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          if (res.headers['content-type']?.includes('application/json')) {
            resolve(JSON.parse(data));
          } else {
            resolve(data);
          }
        } catch (e) {
          resolve(data);
        }
      });
    });
    req.on('error', reject);
    if (options.body) {
      req.write(options.body);
    }
    req.end();
  });
}

async function getFromOpenAI(song, artist) {
  if (!process.env.OPENAI_API_KEY) return null;
  
  const prompt = `What is the detailed story, meaning, and inspiration behind "${song}" by ${artist}? Include specific context, real events, and human stories. ALWAYS include 1-2 key lyric quotes that best illustrate the song's meaning. Write in 2-3 engaging paragraphs. Focus on compelling stories, tragedies, or real incidents if they exist.`;
  
  const body = JSON.stringify({
    model: "gpt-4o-mini",
    messages: [
      {
        role: "system",
        content: "You write engaging song-meaning summaries in 2-3 detailed paragraphs. Focus on the compelling story, inspiration, or meaning behind the song. Include specific details, real events, and human stories. ALWAYS include 1-2 key lyric quotes that illustrate the meaning, formatted with quotation marks. If there was a death, accident, tragedy, or specific event, describe it with appropriate detail. Make it informative and engaging but not overly long. DO NOT start with the song title - jump straight into the story."
      },
      { role: "user", content: prompt }
    ],
    max_tokens: 400,
    temperature: 0.2
  });

  try {
    const response = await makeRequest('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`
      },
      body: body
    });

    return response?.choices?.[0]?.message?.content?.trim() || null;
  } catch (e) {
    console.error('OpenAI error:', e);
    return null;
  }
}

exports.handler = async (event) => {
  console.log('Event:', JSON.stringify(event, null, 2));
  
  // Handle CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
      },
      body: ''
    };
  }

  // Parse query parameters
  const params = event.queryStringParameters || {};
  const song = params.song || '';
  const artist = params.artist || '';

  if (!song) {
    return {
      statusCode: 400,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ error: 'song parameter is required' })
    };
  }

  if (!artist || !artist.trim()) {
    return {
      statusCode: 400,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ error: 'artist parameter is required' })
    };
  }

  try {
    const meaning = await getFromOpenAI(song.trim(), artist.trim());
    
    if (!meaning) {
      return {
        statusCode: 404,
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ error: 'Could not find meaning for this song' })
      };
    }

    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        song: song.trim(),
        artist: artist.trim(),
        meaning: meaning
      })
    };
  } catch (error) {
    console.error('Handler error:', error);
    return {
      statusCode: 500,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ error: 'Internal server error' })
    };
  }
};
